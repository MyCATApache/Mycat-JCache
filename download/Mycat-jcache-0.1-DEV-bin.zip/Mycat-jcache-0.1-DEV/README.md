# Mycat-JCache
A high performance  Memcache developed by Mycat team ,used Java NIO and Off-heap Memory ,QQ group : 490435960
